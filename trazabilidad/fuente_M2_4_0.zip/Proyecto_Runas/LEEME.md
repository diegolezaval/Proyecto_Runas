# Rúnica · Proyecto técnico 4.0.0

**Empieza por [M2_RESULTADO.md](M2_RESULTADO.md): prueba directa de la guía, resultados, límites y reproducción.**

La guía autosostenida de dos campos se ha resuelto y presenta inestabilidad longitudinal. No se ha obtenido la demostración positiva de guía y terminal estables que requiere P-04.

**Empieza por [Runica_Tratado_integrado.md](Runica_Tratado_integrado.md).** Reúne el tratado, las derivaciones, la especificación R1, los procedimientos, las tablas y las veinticuatro fichas. Para consultar dibujos, abre [graficos/atlas.svg](graficos/atlas.svg) en un navegador o editor vectorial.

La interfaz de uso se reduce a tarea, región y consigna. La ingeniería que la sostiene incluye captación, reservas, apoyo, control local, medidas y evacuación de calor. El modelo cuantifica realizaciones de referencia sin atribuir al operador una cuota arbitraria de potencia.

## Contenido y autoridad

| Ruta | Contenido | Cómo se modifica |
|---|---|---|
| `tratado/01_tratado.md` | Principios, arquitectura y repertorio conceptual | Edición directa |
| `tratado/02_micro_derivaciones.md` | Acción, tensores, estabilidad y correspondencia | Edición directa |
| `tratado/03_especificacion_operacional.md` | Contratos y leyes operacionales R1 | Edición directa |
| `tratado/04_procedimientos_y_casos.md` | Casos y procedimientos cuantificados | Edición directa; actualizar cálculos si cambian supuestos |
| `datos/geometria.json` | Tres piezas, transformaciones racionales, uniones y puertos | Fuente única de geometría |
| `datos/parametros.json` | Valores, unidades, significado y estado de evidencia | Fuente de objetivos R1 y casos; Θ escalar común en `datos/theta_comun.json` |
| `datos/modulos.json` | Texto específico de las 24 primordiales | Fuente de las fichas |
| `datos/modelos.json` | Estados, entradas, salidas y contratos reducidos | Fuente de contratos; ecuaciones descriptivas |
| `datos/microscopia.json` | Parámetros y alcance de los ensayos microscópicos | Fuente de perfiles de ensayo |
| `datos/correspondencia.json` | Mecanismo, coeficientes y evidencia por primordial | Fuente de la correspondencia |
| `datos/interfaces.json` | Vocabulario de puertos, unidades y compatibilidad | Contrato de integración |
| `datos/recetas.json` | Cuatro máquinas de estados para tareas de referencia | Especificación de secuencias |
| `datos/revision.json` | Los 50 hallazgos, por prioridad y con estado | Registro de corrección y límites |
| `datos/procedencia.json` | Fuente y cambios de edición | Trazabilidad |
| `fichas/` | 24 fichas derivadas | Regenerar; no editar por separado |
| `graficos/` | Atlas, piezas, glifos y planos técnicos SVG | Regenerar desde JSON |
| `validacion/` | Resultados, residuos, perfil radial y comprobaciones | Regenerar mediante scripts |
| `herramientas/` | Generación y comprobaciones reproducibles | Código Python legible |

Las tablas de parámetros, revisión, resultados y el documento integrado son derivados. Las cifras redondeadas en la prosa deben revisarse si se cambian parámetros: el generador no interpreta ni recalcula frases en lenguaje natural. Los scripts detectan las inconsistencias concretas que cubren sus pruebas, no cualquier contradicción imaginable.

## Estado técnico

La edición 4 añade análisis del problema de Cauchy, vacío e hiperbolicidad; espectros de dos campos; transitorios no lineales; límites cuantitativos y la prueba de una guía autosostenida inestable. Los capítulos 13–18 y `datos/aceptacion_m2.json` fijan el estado vigente. Ninguna primordial se acepta como completamente derivada.

Se distinguen postulados, objetivos adoptados, deducciones y resultados verificados. R1 es una especificación operacional cuantificada; no un conjunto de mediciones. Se incluyen soluciones radiales M1 y M2, una compleción del potencial mediante mediador, dispersión de grafos, memoria modal, bombeo paramétrico y un ciclo térmico. Cada ensayo declara su alcance. No demuestra los 24 dispositivos, el primer arranque manual ni la existencia de un único conjunto microscópico de parámetros que alcance simultáneamente R1.

Esos límites figuran en el tratado y en la revisión: no se ocultan bajo la palabra «completo». El paquete entrega la arquitectura, los datos, las geometrías y los procedimientos especificados. La correspondencia física completa sigue siendo un problema de investigación. Las modalidades biológicas y nucleares no tienen un perfil operativo habilitado en esta edición.

## Reproducción

Los nuevos ensayos se reproducen con los comandos de [M2_RESULTADO.md](M2_RESULTADO.md). `requirements.txt` registra las versiones usadas. Los comandos siguientes conservan la reproducción de los sectores de ediciones previas.

Para leer MD y JSON basta un editor de texto. Los SVG son archivos vectoriales autónomos, sin fuentes remotas ni scripts. Un visor Markdown con soporte de LaTeX presenta las fórmulas; el texto fuente conserva todas las ecuaciones aunque el visor no las renderice.

Desde esta carpeta, con Python 3.10 o posterior:

```bash
python herramientas/generar.py
python herramientas/verificar.py
python herramientas/generar.py
```

La última generación incorpora los resultados actuales al integrado. Para repetir además el ensayo microscópico se requieren NumPy y SciPy; las figuras requieren también Matplotlib:

```bash
python herramientas/ensayo_microscopico.py
python herramientas/correspondencia_micro.py
python herramientas/complecion_escalar.py
python herramientas/preparacion_y_motor.py
python herramientas/graficos_micro.py
python herramientas/resultados_micro.py
python herramientas/verificar.py
python herramientas/generar.py
```

El ensayo usa continuación de soluciones para evitar confundir la solución nula con un condensado. Registra dos dominios, refinamiento, identidad virial y cociente energía/carga. Las versiones del entorno de cálculo se registran en la validación. No hace falta ejecutar código para consultar los resultados incluidos.

El código de verificación comprueba geometría, contratos y casos reducidos. No maneja hardware ni ejecuta órdenes físicas. El archivo `MANIFIESTO_SHA256.json` permite identificar los bytes entregados; cambia al editar cualquier archivo y no se regenera al ejecutar los scripts anteriores.
