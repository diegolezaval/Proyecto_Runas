"""Registro de decisiones; no genera supuestas realizaciones de las primordiales."""
import json
from pathlib import Path
R=Path(__file__).resolve().parents[1]
geo=json.loads((R/'datos/geometria.json').read_text())
families={
 'transporte':[4,8,13,16],
 'informacion_control':[7,9,10,11,12,14,15],
 'mecanica':[2,3,19,21],
 'energia_termica':[1,5,6,17,18,20],
 'materia_quimica':[22,23,24]}
specific={
1:('Preparacion','El cero clasico es invariante; el bombeo neutro no crea carga neta aislada.','13.8; 16.4'),
2:('Fuerza y referencia','No hay perfil material con retroaccion que derive fuerza, rigidez y reaccion del anclaje.','13.3; 15.6'),
3:('Frontera y especies','La curva no fija barreras de cada especie, presion soportada ni tasas de fuga.','13.7; 15.6'),
4:('Estabilidad de la guia','El Q-tubo libre de dos campos tiene una banda longitudinal creciente; el extremo fisico no se ha derivado.','18; 16.1'),
5:('Conversion y fuente','El ciclo de tres niveles usa niveles y tasas no derivados; el benchmark desacoplado no absorbe potencia runica de luz.','13.2; 16.3'),
6:('Estado, carga y acceso','La Q-ball almacena energia, pero no se ha realizado la geometria de Reserva ni carga/descarga, eficiencia o capacidad R1.','14.1; 15.5'),
7:('Control fisico','No se ha obtenido de M2 un estado de compuerta con contraste, trabajo de control y ruido calculados.','15.6'),
8:('Guias y uniones','La matriz de grafo presupone modos transversales e impedancias; no hay solucion M2 de la union.','16.1'),
9:('Acoplamiento de medida','Ganancia, retroaccion y correlaciones de ruido no estan determinadas por el trazo.','15.6'),
10:('Observable del objetivo','El selector necesita un acoplamiento material que distinga objetivos y cuantifique falsos positivos.','13.2; 15.6'),
11:('Estados y barrera','La fase U(1) tiene barrera cero; Kerr, disipacion y escritura del ensayo anterior no fueron derivados de esta geometria.','16.2'),
12:('No linealidad y lectura','No se ha derivado el umbral de decision, su transductor ni su distribucion de error.','15.6'),
13:('Dispersion y almacenamiento','El retardo depende de dispersion y resonancias; longitud/v no demuestra ruido, ancho de banda ni perdidas M2.','16.1'),
14:('Oscilacion y referencia','Una frecuencia modal no demuestra un reloj alimentado con estabilidad, arranque y difusion de fase calculados.','14.5; 15.6'),
15:('Estados y transiciones','La maquina de estados operacional no especifica estados microscopicos ni tasas de transicion.','13.1; 15.6'),
16:('Aislamiento espacial','Dos componentes desconectados del grafo no prueban diafonia nula en los campos 3D.','13.7; 15.6'),
17:('Emision electromagnetica','Falta el acoplamiento modal que convierta energia en fotones; b=0 implica conversion directa nula.','13.2; 15.6'),
18:('Contactos termicos','No estan definidos los acoplamientos y correlaciones de ambos contactos; se cuantifica el contraste de canales termicos.','16.3'),
19:('Momento y actuador','No hay solucion campo-materia que derive impulso, potencia, reaccion y saturacion.','13.3; 15.6'),
20:('Respuesta electromagnetica','B escalar uniforme no introduce birrefringencia local; una respuesta anisotropa por geometria exige resolver Maxwell y materia.','17.3'),
21:('Elasticidad y perdida','El modo cuadrupolar calculado no es un actuador material; falta acoplamiento, amortiguamiento y esfuerzo maximo.','14.5; 15.3'),
22:('Fuera de esta etapa','Diferida expresamente por instruccion: requiere puente a materia y transporte de especies.','17.4'),
23:('Fuera de esta etapa','Diferida expresamente por instruccion: requiere Hamiltoniano quimico y tasas derivadas.','17.4'),
24:('Fuera de esta etapa','Diferida expresamente por instruccion: requiere quimica, transporte, estructura y errores acumulados.','17.4')}
gates=['geometria_fisica','theta_total_identificada','coeficientes_derivados','solucion_del_dispositivo','estabilidad_del_dispositivo','dinamica_operacional','perdidas_y_ruido','preparacion','funcion_R1','limites_operativos']
rows=[]
for rune in geo['runes']:
    number=int(rune['id'][2:]);family=next(k for k,v in families.items() if number in v)
    gate,reason,ref=specific[number]
    rows.append({'id':rune['id'],'name':rune['name'],'family':family,
      'decision':'diferida_por_instruccion' if number>=22 else 'no_aceptada_como_derivada',
      'first_identified_obstruction':gate,'reason':reason,'evidence_sections':ref,
      'canonical_axis_geometry_available':True,'common_scalar_benchmark_available':True,
      'complete_chain':{g:False for g in gates},'complete_device_derived':False})
out={'schema_version':'4.0.0','criterion':'Conjuncion de todos los eslabones cuantitativos; un sector no sustituye al dispositivo.',
     'accepted_count':0,'evaluated_catalog_count':21,'explicitly_deferred_count':3,
     'end_to_end_realization_demonstrated':False,'runes':rows}
(R/'datos/aceptacion_m2.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
intro='''# Aplicación del criterio al catálogo

## 17.1. Decisión de extensión

La condición previa solicitada —un primer dispositivo completamente derivado, seguido de Memoria e Intercambio térmico— no se cumple. Por tanto, **no se presenta una extensión física demostrada a las otras primordiales**. El inventario siguiente aplica el mismo criterio de aceptación y localiza la primera obstrucción identificada. No añade nuevos coeficientes ni mecanismos postulados para fabricar una aprobación.

Los valores R1 permanecen como contratos de diseño. Ninguna fila habilita un intervalo operativo, umbral de daño, tasa de error o capacidad no calculados. Cero aceptaciones no significa que las ecuaciones prohíban todas las funciones; significa que ninguna satisface la cadena exigida con la evidencia disponible.

## 17.2. Familias y resultado por primordial

'''
for family,ids in families.items():
    intro+='### '+family.replace('_',' / ')+'\n\n| Primordial | Primer eslabón sin demostración de dispositivo | Resultado o razón | Evidencia |\n|---|---|---|---|\n'
    for r in rows:
        if r['family']==family:intro+=f'| {r["id"]} {r["name"]} | {r["first_identified_obstruction"]} | {r["reason"]} | {r["evidence_sections"]} |\n'
    intro+='\n'
intro+='''## 17.3. Precisiones transversales

La mecánica necesita un tensor de tensiones y una referencia que reciba la reacción. Un fluido escalar isotrópico carece de módulo de corte estático; un entramado podría adquirir rigidez por su estructura, pero esa estructura debe ser una solución estable y no un módulo de Young asignado después.

En una región homogénea con el portal electromagnético escalar y sin materia polarizable adicional, la lagrangiana es proporcional a B(E²−B_magnético²). En unidades de vacío, ε=B y μ=1/B: su producto vale uno y la velocidad de frente sigue siendo c. El factor escalar cambia la impedancia y el acoplamiento, pero no introduce por sí solo birrefringencia ni distingue las dos polarizaciones. Interfaces y geometrías pueden generar respuesta selectiva; necesitan su solución vectorial y no quedan excluidas por este resultado local.

Los balances de energía, información y entropía son restricciones necesarias compartidas. Cumplirlos no demuestra la existencia de estados de control, actuadores o contactos. De igual modo, un error numérico pequeño en una ecuación reducida no mide el error físico de sustituir un dispositivo por esa ecuación.

## 17.4. P-22, P-23 y P-24

Separación, Reacción y Ensamblaje quedan fuera de esta etapa por la instrucción expresa del proyecto. Las fichas históricas se conservan como especificaciones, sin atribuirles una realización microscopica ni parámetros de operación validados. No se extiende a química real el ejemplo abstracto de dos estados de la edición anterior.

## 17.5. Resultado final de esta evaluación

Se ha establecido un sector M2 escalar común con problema de Cauchy controlado, vacío estable, propagación causal y evidencia numérica reproducible de un estado cargado con modos radiales y no radiales. La prueba directa de guía autosostenida del capítulo 18 obtiene una banda longitudinal inestable. No se han derivado un extremo estable, preparación operacional ni acoplamiento térmico/material común que realicen R1. El catálogo registra 0 dispositivos completamente derivados, 21 evaluados respecto de sus dependencias y 3 diferidos expresamente. Ningún resultado condicional se contabiliza como una primordial terminada.
'''
(R/'tratado/17_aceptacion_catalogo.md').write_text(intro)
print('Catalogo evaluado: 21; diferidas expresamente: 3; aceptadas como derivadas: 0.')
