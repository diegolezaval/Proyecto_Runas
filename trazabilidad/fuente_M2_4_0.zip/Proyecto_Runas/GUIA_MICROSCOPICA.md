# Guía microscópica · 4.0.0

El resultado vigente está en [M2_RESULTADO.md](M2_RESULTADO.md). Incluye la prueba directa del tubo de dos campos y su inestabilidad longitudinal, junto con el análisis del exterior del terminal.

Los capítulos 13–18 contienen los teoremas, cálculos, dominios de validez y decisiones de aceptación. Los capítulos 08–12 conservan los ensayos anteriores como antecedentes; sus grafos, memoria Kerr y motor de tres niveles no cuentan como dispositivos derivados de M2.

El conjunto escalar común está en `datos/theta_comun.json`. `datos/parametros.json` conserva las metas R1, separadas de los coeficientes calculados. P-22, P-23 y P-24 permanecen diferidas por instrucción expresa.
