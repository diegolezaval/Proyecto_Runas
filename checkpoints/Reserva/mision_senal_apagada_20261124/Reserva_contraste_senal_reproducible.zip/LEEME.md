# Reserva · reproducción de la primera descarga y de la misión de señal apagada

Desde la raíz de este paquete, con Python, NumPy 2 y Matplotlib:

    python checkpoints/Reserva/diagnostico_primera_descarga_20261124/diagnosticar.py
    python checkpoints/Reserva/mision_senal_apagada_20261124/analizar.py

Los informes y las figuras SVG están en esos dos directorios. Hay nueve series encendidas y seis apagadas, tres estados radiales de partida y los dos manifiestos de la descarga original. Para volver a medir la superposición inicial o regenerar las seis trayectorias se necesitan también SciPy y un compilador C compatible con GCC:

    python checkpoints/Reserva/diagnostico_primera_descarga_20261124/medir_solapamiento.py
    OPENBLAS_NUM_THREADS=1 python checkpoints/Reserva/mision_senal_apagada_20261124/ejecutar.py salida_nueva --jobs 6
    python checkpoints/Reserva/mision_senal_apagada_20261124/analizar.py salida_nueva

El segundo comando genera los seis estados finales nuevos junto a sus series. Las huellas de la ejecución publicada están en mision_senal_apagada_20261124/datos/EJECUCION.json. Para el archivo de los nueve estados finales históricos véase el recibo original. Esta reproducción parte de los campos radiales.
