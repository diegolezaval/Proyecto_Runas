# Reserva · ensayo del paquete negativo en Φ

El informe y los comandos de reproducción están en `checkpoints/Reserva/mision_paquete_negativo_20261125/README.md`.

Desde esta carpeta, `sha256sum -c HUELLAS_PAQUETE.sha256` comprueba la descarga. Las 50 series permiten rehacer el análisis. Los insumos permiten regenerar las seis preparaciones amplias y los 25 estados finales, también publicados individualmente en la rama.
